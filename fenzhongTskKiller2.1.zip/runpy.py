import easygui as ez
import sys,os
ez.msgbox("请你安装Python以确保运行")
a = ez.enterbox("同意请输入0不同意请输入1")
main = "python-3.6.4.exe"
f = os.popen(main)
data = f.readlines()
f.close()
print (data)
if a == 0:
    os.system("./python-3.6.4.exe")
else:
    sys.exit()
