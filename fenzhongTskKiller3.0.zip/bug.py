from email.mime.text import MIMEText

import easygui,email

import smtplib

from email.mime.text import MIMEText
# conding UTF-8
et = easygui.enterbox("请输入你的邮箱")
et2 = easygui.enterbox("请输入不带@的邮箱账号")
ps = easygui.enterbox("请输入你的授权码")
sv = easygui.enterbox("输入smtp地址")
sb = easygui.enterbox("请输入您的反馈内容")
pt = 465
to = "bbw0319@126.com"
msg = MIMEText("Bug Report:" + sb)
message = MIMEText(sb,'plain','utf-8')
message['Subject'] = 'Bug Report:'
message['From'] = et
message['To'] = to[0]

try:
    smtpObj = smtplib.SMTP()
    smtpObj.connect(sv,25)
    smtpObj.login(et2,ps)
    smtpObj.sendmail(
        et,to,message.as_string())
    smtpObj.quit()
except smtplib.SMTPException as e:
    print("er")