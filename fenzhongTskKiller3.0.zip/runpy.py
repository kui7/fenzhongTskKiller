import easygui as ez
import sys,os
ez.msgbox("请你安装Python以确保运行")
a = ez.enterbox("同意请输入0不同意请输入1")

if a == "0":
    a = "RunDev.bat"
    d = os.popen(a)
    data = d.readlines()
    d.close()
else:
    sys.exit()


