# 这是新建文件asxas.py
# 这是新建文件tsk.py
# encoding:utf-8
import easygui,_thread,time
import os, sys, webbrowser
import smtplib
from email.mime.text import MIMEText
import importlib
from subprocess import Popen

import tkinter as tk, time

importlib.reload(sys)

window = tk.Tk()
window.title('fenzhongTskKiller2.0')
window.geometry('500x500')
# RName = tk.Entry(window, show=None, font=('Arial', 14))
# RName.pack()
on_hit = False
def printtime( threadName, delay):
   count = 0
   while count < 5:
      time.sleep(delay)
      count += 1
      print ("%s: %s" % ( threadName, time.ctime(time.time())))
try:
   _thread.start_new_thread(printtime, ("Thread-1", 2, ))
   _thread.start_new_thread(printtime, ("Thread-2", 4, ))
except:
   print ("Error: 无法启动线程")
def hit_me():
    global on_hit
    if on_hit == False:
        on_hit = True
        RName1 = easygui.enterbox('请输入进程名')
        # 使用Python的os.system运行CMD命令乱码解决
        os.system('chcp 65001')

        # 获取进程信息
        print(os.popen('tasklist /FI "IMAGENAME eq YoudaoDict.exe"').read())

        # 判断进程
        print(RName1 in os.popen('tasklist /FI "IMAGENAME eq YoudaoDict.exe"').read())

        # 杀死进程
        print(os.system('TASKKILL /F /IM ' + RName1))

        print(RName1 in os.popen('tasklist /FI "IMAGENAME eq YoudaoDict.exe"').read())



    else:
        on_hit = False


onhit = False


def hitme():
    RName1 = "QQPCTray.exe"
    RName2 = "QQPCRTP.exe"
    RName3 = "QQPCMgr.exe"
    RName4 = "TQSERV.exe"
    RName5 = "QQBrowser.exe"
    RName6 = "haozip.exe"
    RName7 = "HaozipMiniPage.exe"
    RName8 = "kxetray.exe"
    RName9 = "kislive.exe"
    RName10 = "knewvip.exe"
    RName11 = "Kuaizip.exe"
    RName12 = "360tray.exe"

    global onhit
    if onhit == False:
        onhit = True
        # 使用Python的os.system运行CMD命令乱码解决
        os.system('chcp 65001')

        # 获取进程信息
        print(os.popen('tasklist /FI "IMAGENAME eq YoudaoDict.exe"').read())

        # 判断进程
        print(RName1 in os.popen('tasklist /FI "IMAGENAME eq YoudaoDict.exe"').read())

        # 杀死进程
        print(os.system('TASKKILL /F /IM ' + RName1))

        print(RName1 in os.popen('tasklist /FI "IMAGENAME eq YoudaoDict.exe"').read())

        # 判断进程
        print(RName2 in os.popen('tasklist /FI "IMAGENAME eq YoudaoDict.exe"').read())

        # 杀死进程
        print(os.system('TASKKILL /F /IM ' + RName2))

        print(RName2 in os.popen('tasklist /FI "IMAGENAME eq YoudaoDict.exe"').read())

        # 判断进程
        print(RName3 in os.popen('tasklist /FI "IMAGENAME eq YoudaoDict.exe"').read())

        # 杀死进程
        print(os.system('TASKKILL /F /IM ' + RName3))

        print(RName3 in os.popen('tasklist /FI "IMAGENAME eq YoudaoDict.exe"').read())

        # 判断进程
        print(RName4 in os.popen('tasklist /FI "IMAGENAME eq YoudaoDict.exe"').read())

        # 杀死进程
        print(os.system('TASKKILL /F /IM ' + RName4))

        print(RName4 in os.popen('tasklist /FI "IMAGENAME eq YoudaoDict.exe"').read())

        # 判断进程
        print(RName5 in os.popen('tasklist /FI "IMAGENAME eq YoudaoDict.exe"').read())

        # 杀死进程
        print(os.system('TASKKILL /F /IM ' + RName5))

        print(RName5 in os.popen('tasklist /FI "IMAGENAME eq YoudaoDict.exe"').read())

        # 判断进程
        print(RName6 in os.popen('tasklist /FI "IMAGENAME eq YoudaoDict.exe"').read())

        # 杀死进程
        print(os.system('TASKKILL /F /IM ' + RName6))

        print(RName6 in os.popen('tasklist /FI "IMAGENAME eq YoudaoDict.exe"').read())

        # 判断进程
        print(RName7 in os.popen('tasklist /FI "IMAGENAME eq YoudaoDict.exe"').read())

        # 杀死进程
        print(os.system('TASKKILL /F /IM ' + RName7))

        print(RName7 in os.popen('tasklist /FI "IMAGENAME eq YoudaoDict.exe"').read())

        # 判断进程
        print(RName8 in os.popen('tasklist /FI "IMAGENAME eq YoudaoDict.exe"').read())

        # 杀死进程
        print(os.system('TASKKILL /F /IM ' + RName8))

        print(RName8 in os.popen('tasklist /FI "IMAGENAME eq YoudaoDict.exe"').read())

        # 判断进程
        print(RName9 in os.popen('tasklist /FI "IMAGENAME eq YoudaoDict.exe"').read())

        # 杀死进程
        print(os.system('TASKKILL /F /IM ' + RName9))

        print(RName9 in os.popen('tasklist /FI "IMAGENAME eq YoudaoDict.exe"').read())

        # 判断进程
        print(RName10 in os.popen('tasklist /FI "IMAGENAME eq YoudaoDict.exe"').read())

        # 杀死进程
        print(os.system('TASKKILL /F /IM ' + RName10))

        print(RName10 in os.popen('tasklist /FI "IMAGENAME eq YoudaoDict.exe"').read())

        # 判断进程
        print(RName11 in os.popen('tasklist /FI "IMAGENAME eq YoudaoDict.exe"').read())

        # 杀死进程
        print(os.system('TASKKILL /F /IM ' + RName11))

        print(RName11 in os.popen('tasklist /FI "IMAGENAME eq YoudaoDict.exe"').read())

        # 判断进程
        print(RName12 in os.popen('tasklist /FI "IMAGENAME eq YoudaoDict.exe"').read())

        # 杀死进程
        print(os.system('TASKKILL /F /IM ' + RName12))

        print(RName12 in os.popen('tasklist /FI "IMAGENAME eq YoudaoDict.exe"').read())



    else:
        onhit = False


ot = False


def ntsd():
    global ot
    if ot == False:
        ot = True
        # shutil.copy('./ntsd.exe', 'C:/Windows/System32')
        # shutil.copy('./ntsd.exe', 'C:/Windows')
        # time.sleep(1)
        os.system("./ntsd.exe")
        os.system("./Kill360.bat")

        Popen("./Kill360.bat")
        # os.remove("C:/Windows/System32")
        # os.remove('C:/Windows')
    else:
        ot = False


# BUG反馈
BD = False


def BUG():
    global BD

    if BD == False:
        BD = True


    else:
        BD = False


ck = False


def checkvr():
    global ck
    if ck == False:
        ck = True
        easygui.msgbox("当前流氓库版本为2.0 包括少量流氓软件")
    else:
        ck = False


delete = False


def dele():
    global delete
    if delete == False:
        delete = True
        # os.remove("C:/")


a = tk.Button(window, text='开始', font=('Arial', 12), width=10, height=1, command=hit_me)
kl = tk.Button(window, text='杀死流氓', font=('Arial', 12), width=10, height=1, command=hitme)
ntsd = tk.Button(window, text='强制杀死流氓', font=('Arial', 12), width=10, height=1, command=ntsd)
tg = tk.Button(window, text='BUG反馈(TND真有BUG!', font=('Arial', 12), width=10, height=1, command=BUG)
checkvr = tk.Button(window, text='流氓库版本号', font=('Arial', 10), width=10, height=1, command=checkvr)
dele = tk.Button(window, text='无法使用)删除2345等.sys', font=('Arial', 7), width=10, height=1, command=dele)

a.pack()
kl.pack()
ntsd.pack()
tg.pack()
dele.pack()
checkvr.pack()

window.mainloop()
